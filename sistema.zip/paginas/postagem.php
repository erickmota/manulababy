<html>

<head>

    <title>Postagem</title>

</head>

<body>

    <form enctype="multipart/form-data" action="php/postagem.php" method="POST">

        Variação1: <input type="text" name="id_variacao_produto"><br>

        Variação2: <input type="text" name="id_variacao_produto2"><br>

        Variação3: <input type="text" name="id_variacao_produto3"><br>

        Promoção: <input type="text" name="id_promocoes"><br>

        Tamanho: <input type="text" name="tamanho"><br>

        Nome: <input type="text" name="nome"><br>

        Foto: <input type="file" name="foto"><br>

        Descrição: <textarea name="descricao"></textarea><br>

        preco: <input type="text" name="preco"><br>

        estoque: <input type="text" name="qtd_estoque"><br>

        estado: <input type="text" name="estado"><br>

        promocao: <input type="text" name="preco_promocao"><br>

        sexo: <input type="text" name="sexo"><br>

        peso: <input type="text" name="peso"><br>

        altura: <input type="text" name="altura"><br>

        largura: <input type="text" name="largura"><br>

        comprimento: <input type="text" name="comprimento"><br>

        dias_entrega: <input type="number" name="dias_entrega"><br>

        <button type="submit">Enviar</button>

    </form>

</body>

</html>